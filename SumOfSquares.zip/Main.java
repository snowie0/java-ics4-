/* Ruveyda Nur Kizmaz
ICS4UI
May 28, 2021
SumOfSquares.java
Calculates the sum of all powers where base and exponent are user inputs.
*/

import java.util.*;
import java.lang.Math;

class Main {
  public static void main(String[] args) {

    double x, n, sum =1; //sum i 1 because I skipped 1 since it will not change.
    
    Scanner input = new Scanner(System.in);
    
    System.out.print("Please enter a base: ");
    x = input.nextDouble();// x for base of power

    System.out.print("Please enter the number of powers: ");
    n = input.nextDouble(); //n is the number of times it will repeat

    System.out.print("1"); //this is power of 0 so will be always 1

    for (int i = 1; i < n ; i++){ //i starts from 1 because we skipped x^0 and started from x^1.
      System.out.print(" + " + x + "^" + i + " ");  
      sum += Math.pow(x,i); //sum tracking the sum of all powers.
    }

    System.out.print("\nThe sum of the calculation is: "+sum); //displaying results


  }
}